'use strict';
(function(){
 const overlay=document.querySelector('#intro-overlay'),timeline=window.__timelines?.['coffee-intro'];
 const main=document.querySelector('main'),sidebar=document.querySelector('.sidebar'),skip=document.querySelector('#intro-skip');
 let finishing=false,previousFocus=null,fallbackTimer;
 function endIntro(){
  if(overlay.hidden||finishing)return;finishing=true;clearTimeout(fallbackTimer);timeline?.pause();
  try{sessionStorage.setItem('ruang-kopi-intro-seen','1');}catch(_){}
  const finish=()=>{overlay.hidden=true;document.body.classList.remove('intro-active');main.inert=false;sidebar.inert=false;finishing=false;(previousFocus?.isConnected?previousFocus:document.querySelector('#page')).focus({preventScroll:true});};
  if(!window.matchMedia('(prefers-reduced-motion: reduce)').matches&&overlay.animate){
   overlay.animate([{opacity:1},{opacity:0}],{duration:320,easing:'ease-out'}).finished.then(finish,finish);
  }else finish();
 }
 function startIntro(){
  if(!timeline)return;
  finishing=false;previousFocus=document.activeElement;overlay.hidden=false;main.inert=true;sidebar.inert=true;document.body.classList.add('intro-active');
  skip.focus({preventScroll:true});
  timeline.eventCallback('onUpdate',()=>{overlay.querySelector('.intro-progress span').style.width=(timeline.progress()*100)+'%';});
  timeline.eventCallback('onComplete',endIntro);
  if(window.matchMedia('(prefers-reduced-motion: reduce)').matches){timeline.progress(1).pause();endIntro();return;}
  timeline.restart();clearTimeout(fallbackTimer);fallbackTimer=setTimeout(endIntro,9000);
 }
 skip.addEventListener('click',endIntro);document.querySelector('#intro-enter').addEventListener('click',endIntro);
 document.querySelector('#intro-replay')?.addEventListener('click',startIntro);
 overlay.addEventListener('keydown',event=>{
  if(event.key==='Escape'){event.preventDefault();endIntro();}
  if(event.key==='Tab'){const enter=document.querySelector('#intro-enter');if(event.shiftKey&&document.activeElement===skip){event.preventDefault();enter.focus();}else if(!event.shiftKey&&document.activeElement===enter){event.preventDefault();skip.focus();}}
 });
 let seen=false;try{seen=sessionStorage.getItem('ruang-kopi-intro-seen')==='1';}catch(_){}
 if(!seen&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches)startIntro();
 window.RKIntro={start:startIntro,skip:endIntro};
})();
