'use strict';
// Gerakan hanya mengubah tampilan angka. Nilai hitungan tetap berasal dari finance.js.
(function(){
 const running=new WeakMap();
 function number(element,next,format,previous){
  if(!element)return;
  const active=running.get(element);
  if(active)window.cancelAnimationFrame(active.frame);
  const from=active?.value??previous??Number(element.dataset.value??next);
  element.dataset.value=String(next);
  element.setAttribute('aria-label',format(next));
  const finish=()=>{element.textContent=format(next);running.delete(element);};
  if(from===next||!Number.isFinite(from)||window.matchMedia('(prefers-reduced-motion: reduce)').matches||!window.requestAnimationFrame){finish();return;}
  const state={value:from,frame:0,start:null};running.set(element,state);
  const tick=time=>{
   if(!element.isConnected){running.delete(element);return;}
   if(state.start===null)state.start=time;
   const progress=Math.min(1,(time-state.start)/320);
   state.value=from+(next-from)*(1-Math.pow(1-progress,3));element.textContent=format(state.value);
   if(progress<1)state.frame=window.requestAnimationFrame(tick);else finish();
  };
  state.frame=window.requestAnimationFrame(tick);
 }
 window.RKMotion={number};
})();
