'use strict';

// Struktur penyimpanan tetap kompatibel dengan versi pertama.
const defaults = {
  capital: [{name:'Mesin espresso',cost:18000000},{name:'Grinder kopi',cost:5000000},{name:'Renovasi & interior',cost:12000000},{name:'Peralatan & furnitur',cost:7000000},{name:'Stok awal bahan',cost:3000000},{name:'Cadangan kas',cost:5000000}],
  ingredients: [{name:'Biji kopi',cost:3000},{name:'Susu',cost:2500},{name:'Gula & sirup',cost:1000},{name:'Es & air',cost:300},{name:'Cup & kemasan',cost:1200}],
  price:22000,cups:60,days:26,rent:2500000,salary:4000000,utilities:1000000,other:500000
};
const numberKeys = ['price','cups','days','rent','salary','utilities','other'];
let data = structuredClone(defaults), storageOK = true, undoAction = null, toastTimer, announceTimer;
try {
  const raw = JSON.parse(localStorage.getItem('ruang-kopi-v1'));
  if (raw && ['capital','ingredients'].every(key => Array.isArray(raw[key]) && raw[key].every(item => item && typeof item.name === 'string' && Number.isSafeInteger(item.cost) && item.cost >= 0)) &&
      numberKeys.every(key => Number.isSafeInteger(raw[key]) && raw[key] >= 0) && raw.days <= 31) data = raw;
} catch (_) { storageOK = false; }
const money = n => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n);
const integer = n => new Intl.NumberFormat('id-ID').format(n);
const esc = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const iconPaths = {
  grid:'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  wallet:'<path d="M20 8V5a2 2 0 0 0-2-2L5 6a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h15V8H5"/><path d="M20 12h-5v5h5"/><path d="M16 14.5h.1"/>',
  coffee:'<path d="M4 8h13v7a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5V8Zm13 1h2a3 3 0 0 1 0 6h-2M7 3v2m4-2v2m4-2v2M3 22h16"/>',
  chart:'<path d="M4 3v17h17M8 15v-4m5 4V7m5 8V4"/>',
  target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  arrow:'<path d="M5 12h14m-5-5 5 5-5 5"/>',
  back:'<path d="M19 12H5m5-5-5 5 5 5"/>',
  diagonal:'<path d="M6 18 18 6M7 6h11v11"/>',
  download:'<path d="M12 3v12m-4-4 4 4 4-4M4 16v4h16v-4"/>',
  spark:'<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  trash:'<path d="M4 6h16M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7m4-7v7"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/>',
  leaf:'<path d="M5 19C-1 6 12 3 21 3c0 12-5 18-13 15M4 21 16 9"/>'
};
function icon(name) { return '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">'+(iconPaths[name] || iconPaths.spark)+'</svg>'; }
document.querySelectorAll('[data-icon]').forEach(el => el.insertAdjacentHTML('afterbegin', icon(el.dataset.icon)));

const titles = {
  ringkasan:['Halo, calon pemilik kedai.','Selangkah lebih dekat dengan coffee shop impianmu.','Ringkasan','grid'],
  modal:['Ide besar, modal terencana.','Susun kebutuhan pembukaan kedai sesuai rencanamu.','Modal awal','wallet'],
  hpp:['Setiap cup punya cerita.','Kenali biayanya, lalu tentukan harga yang tepat.','HPP per cup','coffee'],
  omzet:['Coba bayangkan ramainya.','Mainkan target penjualan. Lihat potensi pendapatanmu.','Proyeksi omzet','chart'],
  laba:['Biar ramai, juga untung.','Temukan keseimbangan antara penjualan dan biaya.','Laba & BEP','target']
};
const routes = Object.keys(titles), page = document.querySelector('#page');
function route() { const hash = location.hash.slice(1); return Object.hasOwn(titles,hash) ? hash : 'ringkasan'; }
function calc() {
  const capital = data.capital.reduce((sum,item)=>sum+item.cost,0);
  const hpp = data.ingredients.reduce((sum,item)=>sum+item.cost,0);
  const units = data.cups * data.days, revenue = units * data.price;
  const fixed = data.rent + data.salary + data.utilities + data.other;
  const contribution = data.price - hpp, profit = revenue - units*hpp - fixed;
  return {capital,hpp,units,revenue,fixed,contribution,profit,bep:contribution>0?Math.ceil(fixed/contribution):null};
}
function numericField(key,label,max) {
  return '<label class="field"><span>'+label+'</span><input class="input" type="number" min="0" max="'+(max||1000000000000)+'" step="1" inputmode="numeric" data-key="'+key+'" value="'+data[key]+'" aria-describedby="error-'+key+'"><span class="error-text" id="error-'+key+'"></span></label>';
}
function costRows(type) {
  if (!data[type].length) return '<p class="empty-state">Belum ada komponen. Tambahkan yang pertama di bawah.</p>';
  return data[type].map((item,i) => '<div class="money-row" style="--i:'+i+'"><input class="input" maxlength="80" aria-label="Nama '+(type==='capital'?'komponen':'bahan')+' '+(i+1)+'" data-list="'+type+'" data-index="'+i+'" data-prop="name" value="'+esc(item.name)+'"><div class="money-wrap"><span class="currency-prefix">Rp</span><input class="input" type="number" min="0" max="1000000000000" step="1" inputmode="numeric" aria-label="Biaya '+esc(item.name)+' dalam rupiah" aria-describedby="error-'+type+'-'+i+'" data-list="'+type+'" data-index="'+i+'" data-prop="cost" value="'+item.cost+'"><span class="error-text" id="error-'+type+'-'+i+'"></span></div><button class="delete-button" data-remove="'+type+'" data-index="'+i+'" aria-label="Hapus '+esc(item.name)+'" title="Hapus komponen">'+icon('trash')+'</button></div>').join('');
}
function slider(id) {
  const max = Math.max(200,data.cups);
  return '<input class="range" id="'+id+'" type="range" min="0" max="'+max+'" step="1" value="'+data.cups+'" data-key="cups" aria-label="Target cup per hari" style="--range:'+(data.cups/max*100)+'%"><div class="range-labels"><span>0 cup</span><span>'+integer(max)+' cup / hari</span></div>';
}
function scenarios() {
  return '<div class="scenarios" role="group" aria-label="Skenario penjualan">'+[[30,'Santai'],[60,'Normal'],[100,'Ramai']].map(([n,label])=>'<button class="scenario" data-scenario="'+n+'" aria-pressed="'+(data.cups===n)+'"><span>'+label+'</span><strong>'+n+' cup</strong><span>per hari</span></button>').join('')+'</div>';
}
const palette = ['#c1eca2','#c1b4ee','#ffd7a8','#96d8da','#edf6cd','#e5b6c8'];
function distribution(list,amount) {
  if (!list.length || amount===0) return '<div class="result-bottom">Tambahkan biaya untuk melihat komposisi rencanamu.</div>';
  return '<div class="distribution" aria-hidden="true">'+list.map((item,i)=>'<span style="flex:'+item.cost+';background:'+palette[i%palette.length]+'"></span>').join('')+'</div>'+list.map((item,i)=>'<div class="legend"><span class="legend-label"><span class="swatch" style="background:'+palette[i%palette.length]+'"></span><span>'+esc(item.name||'Tanpa nama')+'</span></span><b>'+Math.round(item.cost/amount*100)+'%</b></div>').join('');
}
function resultMarkup() {
  const c=calc(), r=route();
  const head = label => '<div class="result-label">'+label+'<span class="live-pill">LIVE</span></div>';
  const row = (label,value) => '<div class="breakdown"><span>'+label+'</span><b>'+value+'</b></div>';
  const value = amount => '<strong class="big" data-number="'+amount+'">'+money(amount)+'</strong>';
  if(r==='modal') return head('TOTAL MODAL AWAL')+value(c.capital)+'<p>'+data.capital.length+' komponen untuk memulai kedaimu.</p>'+distribution(data.capital,c.capital)+'<div class="result-bottom">Modal yang terencana, langkah pertama yang lebih tenang.</div>';
  if(r==='hpp') return head('BIAYA PER CUP')+value(c.hpp)+'<p>Bahan dan kemasan untuk satu gelas.</p><div class="divider"></div>'+row('Harga jual',money(data.price))+row('Kontribusi per cup',money(c.contribution))+row('Margin kontribusi',data.price>0?(c.contribution/data.price*100).toFixed(1)+'%':'Belum tersedia')+'<div class="result-bottom">'+(c.contribution>0?'Dari setiap cup, <b>'+money(c.contribution)+'</b> tersedia untuk menutup biaya tetap.':'Naikkan harga jual atau tinjau biaya bahan agar setiap cup memberi kontribusi positif.')+'</div>';
  if(r==='omzet') return head('PROYEKSI OMZET BULANAN')+value(c.revenue)+'<p>'+integer(data.cups)+' cup × '+data.days+' hari × '+money(data.price)+'</p><div class="divider"></div>'+row('Omzet per hari',money(data.cups*data.price))+row('Total penjualan per bulan',integer(c.units)+' cup')+'<div class="result-bottom">Bagaimana jika penjualan berubah? Geser slider untuk mencoba kemungkinan lain.</div>';
  return head(c.profit<0?'ESTIMASI RUGI BULANAN':'ESTIMASI LABA BULANAN')+value(c.profit)+'<p>Sebelum pajak dan penyusutan.</p><div class="divider"></div>'+row('Omzet',money(c.revenue))+row('Bahan & kemasan',money(c.units*c.hpp))+row('Biaya tetap',money(c.fixed))+'<div class="divider"></div>'+row('BEP per bulan',c.bep===null?'Tidak tercapai':integer(c.bep)+' cup')+row('Target impas per hari',c.bep===null||data.days===0?'Belum tersedia':integer(Math.ceil(c.bep/data.days))+' cup')+'<div class="result-bottom">'+(c.contribution<=0?'Harga jual harus lebih tinggi dari biaya per cup agar biaya tetap bisa tertutup.':c.profit>=0?'Dengan target sekarang, penjualanmu sudah menutup biaya yang dimasukkan.':'Target sekarang belum menutup seluruh biaya. Coba atur harga, biaya, atau volume penjualan.')+'</div>';
}
function overview(c) {
  return '<section class="hero"><div class="hero-content"><div class="hero-kicker">'+icon('spark')+' DARI IDE, JADI KEDAI.</div><h2>Racik kopimu.<br>Rencanakan <em>mimpimu.</em></h2><p>Bisnis yang tumbuh dimulai dari rencana yang kamu pahami. Yuk, hitung langkah pertamamu.</p><div class="hero-actions"><a class="button" href="#modal">Mulai rencanakan '+icon('arrow')+'</a><a class="text-link" href="#omzet">Coba simulasi '+icon('diagonal')+'</a></div></div><div class="hero-art" aria-hidden="true"><div class="orb orb-one"></div><div class="orb orb-two"></div><div class="cup-scene"><div class="cup-shadow"></div><div class="cup-body"><div class="cup-sleeve">rk.<small>BREW YOUR DREAM</small></div></div><div class="cup-lid"></div></div><div class="floating-tag tag-one"><small>SATU CUP, BANYAK PELUANG.</small><b>Make it happen.</b></div><div class="floating-tag tag-two">'+icon('check')+'Ide bagus. Rencana matang.</div></div></section>'+
  '<div class="section-heading"><h2>Gambaran usahamu</h2><small>ANGKA BERGERAK BERSAMA RENCANAMU</small></div><section class="stats" aria-label="Ringkasan keuangan">'+[
    ['Modal awal',c.capital,'Kebutuhan pembukaan','modal','wallet'],
    ['HPP per cup',c.hpp,'Bahan & kemasan','hpp','coffee'],
    ['Omzet bulanan',c.revenue,integer(c.units)+' cup per bulan','omzet','chart'],
    ['Estimasi laba',c.profit,'Per bulan, sebelum pajak','laba','target']
  ].map(s=>'<a class="stat" href="#'+s[3]+'"><div class="stat-top"><span class="stat-icon">'+icon(s[4])+'</span><span class="stat-arrow">'+icon('diagonal')+'</span></div><span class="stat-label">'+s[0]+'</span><strong data-stat="'+s[3]+'" data-number="'+s[1]+'">'+money(s[1])+'</strong><small '+(s[3]==='omzet'?'id="overview-units"':'')+'>'+s[2]+'</small></a>').join('')+'</section>'+
  '<div class="lower-grid"><section class="panel"><div class="panel-heading"><div><h2>Bangun rencanamu</h2><p>Satu langkah kecil, satu keputusan lebih baik.</p></div><span class="chip">3 langkah awal</span></div>'+[
    ['modal','Susun modal awal','Apa saja yang dibutuhkan untuk mulai?'],
    ['hpp','Kenali biaya setiap cup','Tentukan harga dengan lebih percaya diri.'],
    ['omzet','Temukan target penjualan','Buat gambaran pendapatan yang realistis.']
  ].map((s,i)=>'<a class="step" href="#'+s[0]+'"><span class="step-number">0'+(i+1)+'</span><div><strong>'+s[1]+'</strong><p>'+s[2]+'</p></div>'+icon('arrow')+'</a>').join('')+'</section>'+
  '<section class="panel sim-panel"><div class="panel-heading"><div><h2>Bagaimana jika…</h2><p>Coba geser. Lihat potensi kedaimu.</p></div><span class="stat-icon">'+icon('spark')+'</span></div><div class="sim-value"><b data-cups>'+integer(data.cups)+'</b><span>cup terjual setiap hari</span></div>'+slider('overview-slider')+'<div class="sim-bottom"><div><small>Potensi omzet / bulan</small><strong id="sim-revenue">'+money(c.revenue)+'</strong></div><a href="#omzet">Atur detail '+icon('arrow')+'</a></div></section></div>'+
  '<div class="tip-strip">'+icon('leaf')+'<p><b>Catatan kecil:</b> omzet besar belum tentu untung besar. Kenali biaya di balik setiap cup.</p><a href="#laba">Cari titik impasmu ↗</a></div>';
}
function editor(r) {
  let form='';
  if(r==='modal'||r==='hpp') {
    const type=r==='modal'?'capital':'ingredients';
    form='<div class="editor-heading"><span class="stat-icon">'+icon(titles[r][3])+'</span><div><h2>'+(r==='modal'?'Apa yang kamu butuhkan?':'Bahan untuk satu cup')+'</h2><p>'+(r==='modal'?'Ubah rincian sesuai konsep kedaimu.':'Masukkan biaya pemakaian, bukan harga satu kemasan.')+'</p></div></div><div class="column-labels"><span>NAMA KOMPONEN</span><span>BIAYA (RUPIAH)</span></div><div class="cost-rows">'+costRows(type)+'</div><button class="add-button" data-add="'+type+'">'+icon('plus')+' Tambah '+(r==='modal'?'komponen':'bahan')+'</button>';
    if(r==='hpp') form+='<div class="divider"></div>'+numericField('price','Harga jual per cup (Rp)')+'<p class="helper">'+icon('info')+'Contoh: harga susu Rp20.000/liter, pemakaian 125 ml berarti biaya susu Rp2.500/cup.</p>';
    else form+='<p class="helper">'+icon('info')+'Sertakan peralatan, stok awal, dan cadangan kas. Setiap perubahan langsung dihitung.</p>';
  }
  if(r==='omzet') form='<div class="editor-heading"><span class="stat-icon">'+icon('chart')+'</span><div><h2>Seberapa ramai kedaimu?</h2><p>Pilih skenario atau buat targetmu sendiri.</p></div></div>'+scenarios()+'<div class="field-grid">'+numericField('price','Harga jual per cup (Rp)')+numericField('days','Hari operasional / bulan',31)+numericField('cups','Target cup / hari')+'</div><div class="range-caption"><label for="sales-slider">Geser untuk mencoba</label><output data-cups>'+integer(data.cups)+' cup</output></div>'+slider('sales-slider')+'<p class="helper">'+icon('info')+'Skenario memakai harga yang sama setiap hari, tanpa diskon atau retur.</p>';
  if(r==='laba') form='<div class="editor-heading"><span class="stat-icon">'+icon('target')+'</span><div><h2>Biaya rutin kedaimu</h2><p>Pengeluaran tetap setiap bulan.</p></div></div><div class="field-grid">'+numericField('rent','Sewa tempat (Rp)')+numericField('salary','Gaji tim (Rp)')+numericField('utilities','Listrik, air & internet (Rp)')+numericField('other','Biaya tetap lainnya (Rp)')+'</div><div class="divider"></div><div class="panel-heading"><h2>Ke mana omzetmu pergi?</h2><a class="chip" href="#omzet">Ubah penjualan ↗</a></div><div id="cost-chart">'+costChart()+'</div>';
  const notes={
    modal:'Modal mencakup aset, stok, dan cadangan kas. Tidak semuanya menjadi beban pada bulan pertama.',
    hpp:'Kontribusi per cup belum merupakan laba bersih. Nilai ini masih dipakai untuk membayar biaya tetap.',
    omzet:'Ini proyeksi, bukan transaksi aktual. Hasil mengikuti harga dan target yang kamu masukkan.',
    laba:'Simulasi belum mencakup pajak, penyusutan, bunga, atau biaya yang belum dimasukkan. BEP bukan waktu balik modal.'
  };
  const formulas={
    modal:'Total modal = jumlah seluruh biaya komponen yang kamu masukkan.',
    hpp:'HPP per cup = jumlah biaya bahan dan kemasan. Kontribusi = harga jual − HPP. Margin kontribusi = kontribusi ÷ harga jual × 100%.',
    omzet:'Omzet bulanan = harga jual per cup × cup per hari × hari operasional.',
    laba:'Laba = omzet − biaya bahan dan kemasan − biaya tetap. BEP = biaya tetap ÷ (harga jual − HPP), dibulatkan ke atas.'
  };
  const i=routes.indexOf(r),next=routes[i+1]||'ringkasan',previous=routes[i-1];
  return '<div class="editor-grid"><section class="panel editor-panel">'+form+'</section><div class="result-column"><section class="panel result" id="result" aria-label="Hasil perhitungan">'+resultMarkup()+'</section><p class="result-note">'+notes[r]+'</p><details class="formula"><summary>Cara perhitungan '+icon('arrow')+'</summary><p>'+formulas[r]+'</p></details></div></div><div class="page-nav"><a class="text-link" href="#'+previous+'">'+icon('back')+' '+titles[previous][2]+'</a><a class="button primary" href="#'+next+'">'+(next==='ringkasan'?'Kembali ke ringkasan':'Lanjut: '+titles[next][2])+' '+icon('arrow')+'</a></div>';
}
function costChart() {
  const c=calc(),cost=c.units*c.hpp+c.fixed,max=Math.max(c.revenue,cost,Math.abs(c.profit),1);
  return [['Omzet',c.revenue,''],['Total biaya',cost,'cost'],[c.profit<0?'Selisih rugi':'Sisa laba',Math.abs(c.profit),'profit']].map(([label,value,cls])=>'<div class="chart-row"><div class="chart-label"><span>'+label+'</span><strong>'+money(value)+'</strong></div><div class="chart-track"><div class="chart-fill '+cls+'" style="--width:'+(value/max*100)+'%"></div></div></div>').join('');
}
function updateStatus() {
  document.querySelector('#save-status').innerHTML='<span class="live-dot"></span>'+(storageOK?'Tersimpan di perangkat':'Gagal menyimpan di perangkat');
}
function save() {
  try { localStorage.setItem('ruang-kopi-v1',JSON.stringify(data));storageOK=true; } catch (_) { storageOK=false; }
  updateStatus();
}
function render(animate=true) {
  const r=route();
  document.querySelectorAll('nav a').forEach(a=>{
    const active=a.hash==='#'+r;a.classList.toggle('active',active);
    if(active)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');
  });
  document.querySelector('#breadcrumb-page').textContent=titles[r][2];
  document.title=titles[r][2]+' — Ruang Kopi';
  page.innerHTML='<div class="title-row"><div><div class="eyebrow">'+icon('spark')+' YOUR IDEAS, BREWING.</div><h1>'+titles[r][0]+'</h1><p>'+titles[r][1]+'</p></div><button class="button" id="export" aria-label="Unduh ringkasan CSV">'+icon('download')+'<span class="export-label">Unduh ringkasan</span></button></div>'+(r==='ringkasan'?overview(calc()):editor(r));
  if(animate){page.classList.remove('page-enter');void page.offsetWidth;page.classList.add('page-enter');}
  updateStatus();
  if(animate) animateNumbers();
}
function animateNumbers() {
  if(reducedMotion() || typeof requestAnimationFrame !== 'function') return;
  const nodes=[...page.querySelectorAll('[data-number]')], initial=JSON.stringify(data);
  const start=performance.now(), duration=520;
  function frame(now) {
    if(JSON.stringify(data)!==initial)return;
    const progress=Math.min((now-start)/duration,1), eased=1-Math.pow(1-progress,3);
    nodes.forEach(el=>{ if(el.isConnected) el.textContent=money(Math.round(Number(el.dataset.number)*(.85+.15*eased))); });
    if(progress<1)requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}
function refreshResults() {
  const c=calc(),output=document.querySelector('#result');
  if(output) output.innerHTML=resultMarkup();
  const chart=document.querySelector('#cost-chart');if(chart)chart.innerHTML=costChart();
  const vals={modal:c.capital,hpp:c.hpp,omzet:c.revenue,laba:c.profit};
  document.querySelectorAll('[data-stat]').forEach(el=>el.textContent=money(vals[el.dataset.stat]));
  const revenue=document.querySelector('#sim-revenue');if(revenue)revenue.textContent=money(c.revenue);
  const units=document.querySelector('#overview-units');if(units)units.textContent=integer(c.units)+' cup per bulan';
  document.querySelectorAll('[data-cups]').forEach(el=>el.textContent=integer(data.cups)+(el.tagName==='OUTPUT'?' cup':''));
  document.querySelectorAll('[data-scenario]').forEach(el=>el.setAttribute('aria-pressed',String(Number(el.dataset.scenario)===data.cups)));
  document.querySelectorAll('input[data-key="cups"]').forEach(el=>{
    if(el.type==='range'){el.max=Math.max(200,data.cups);el.style.setProperty('--range',(data.cups/Number(el.max)*100)+'%');el.nextElementSibling.lastElementChild.textContent=integer(Number(el.max))+' cup / hari';}
    if(document.activeElement!==el)el.value=data.cups;
  });
}
function notify(message,undo=null) {
  clearTimeout(toastTimer);undoAction=undo;
  const el=document.querySelector('#toast');
  el.innerHTML=icon('check')+'<span>'+esc(message)+'</span>'+(undo?'<button id="undo">Urungkan</button>':'');
  el.classList.add('show');toastTimer=setTimeout(()=>{el.classList.remove('show');undoAction=null;},undo?8000:3000);
}
function setInputError(el,message) {
  const target=el.getAttribute('aria-describedby');
  if(message)el.setAttribute('aria-invalid','true');else el.removeAttribute('aria-invalid');
  if(target){const error=document.getElementById(target);if(error)error.textContent=message;}
}
page.addEventListener('input',event=>{
  const el=event.target;if(!el.matches('input'))return;
  const numeric=el.type==='number'||el.type==='range';
  if(numeric) {
    const value=Number(el.value),max=Number(el.max)||1000000000000;
    if(el.value===''||!Number.isSafeInteger(value)||value<0||value>max){
      setInputError(el,el.value===''?'Isi angka agar hasil diperbarui.':value<0?'Gunakan angka nol atau lebih.':value>max?'Maksimal '+integer(max)+'.':'Gunakan bilangan bulat.');
      return;
    }
    setInputError(el,'');
  }
  if(el.dataset.key)data[el.dataset.key]=Number(el.value);
  else if(el.dataset.list){
    const item=data[el.dataset.list][Number(el.dataset.index)];
    item[el.dataset.prop]=el.dataset.prop==='cost'?Number(el.value):el.value;
    if(el.dataset.prop==='name'){
      const row=el.closest('.money-row');
      row.querySelector('[data-prop="cost"]').setAttribute('aria-label','Biaya '+el.value+' dalam rupiah');
      row.querySelector('button').setAttribute('aria-label','Hapus '+el.value);
    }
  }
  save();refreshResults();
  clearTimeout(announceTimer);
  announceTimer=setTimeout(()=>{
    const c=calc(),r=route();
    document.querySelector('#calculation-status').textContent=r==='modal'?'Total modal '+money(c.capital):r==='hpp'?'Biaya per cup '+money(c.hpp):r==='laba'?'Estimasi laba '+money(c.profit):'Proyeksi omzet '+money(c.revenue);
  },650);
});
function exportCSV(){
  const c=calc();
  // Awali teks formula dengan apostrof agar nama komponen aman dibuka di spreadsheet.
  const quote=value=>'"'+String(typeof value==='string'&&/^[=+@\-\t\r]/.test(value)?"'"+value:value).replace(/"/g,'""')+'"';
  const rows=[['RUANG KOPI — RINGKASAN SIMULASI','Nilai'],['Modal awal',c.capital],['HPP per cup',c.hpp],['Harga jual per cup',data.price],['Cup per hari',data.cups],['Hari operasional',data.days],['Omzet bulanan',c.revenue],['Biaya tetap bulanan',c.fixed],['Estimasi laba sebelum pajak',c.profit],['BEP cup per bulan',c.bep??'Tidak tercapai'],[],['Rincian modal','Biaya'],...data.capital.map(x=>[x.name,x.cost]),[],['Bahan per cup','Biaya'],...data.ingredients.map(x=>[x.name,x.cost])];
  const blob=new Blob(['\uFEFF'+rows.map(row=>row.map(quote).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8;'});
  const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='rencana-ruang-kopi.csv';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  notify('Ringkasan CSV berhasil diunduh.');
}
page.addEventListener('click',event=>{
  const b=event.target.closest('button');if(!b)return;
  if(b.dataset.add){
    const type=b.dataset.add;data[type].push({name:type==='capital'?'Komponen baru':'Bahan baru',cost:0});save();render(false);
    const inputs=page.querySelectorAll('[data-list="'+type+'"][data-prop="name"]');
    inputs[inputs.length-1]?.focus();inputs[inputs.length-1]?.select();
    notify(type==='capital'?'Komponen baru ditambahkan.':'Bahan baru ditambahkan.');
  } else if(b.dataset.remove){
    const type=b.dataset.remove,index=Number(b.dataset.index),item=data[type].splice(index,1)[0];
    save();render(false);
    const remaining=page.querySelectorAll('[data-remove="'+type+'"]');(remaining[Math.min(index,remaining.length-1)]||page.querySelector('[data-add]'))?.focus();
    notify('“'+(item.name||'Komponen')+'” dihapus.',()=>{data[type].splice(index,0,item);save();render(false);});
  } else if(b.dataset.scenario){
    data.cups=Number(b.dataset.scenario);save();refreshResults();
    notify('Skenario diubah menjadi '+data.cups+' cup per hari.');
  } else if(b.id==='export')exportCSV();
});
document.querySelector('#toast').addEventListener('click',e=>{
  if(e.target.closest('#undo')&&undoAction){undoAction();notify('Komponen dikembalikan.');}
});
// Umpan balik sentuhan singkat, tanpa menunda aksi tombol.
document.addEventListener('pointerdown',event=>{
  const target=event.target.closest('button,.button');
  if(!target||reducedMotion())return;
  const bounds=target.getBoundingClientRect(),ripple=document.createElement('span'),size=Math.max(bounds.width,bounds.height);
  ripple.className='ripple';ripple.style.cssText='width:'+size+'px;height:'+size+'px;left:'+(event.clientX-bounds.left-size/2)+'px;top:'+(event.clientY-bounds.top-size/2)+'px';
  target.append(ripple);setTimeout(()=>ripple.remove(),650);
});
document.querySelector('.skip-link').addEventListener('click',event=>{event.preventDefault();page.focus({preventScroll:true});page.scrollIntoView({behavior:reducedMotion()?'auto':'smooth'});});
window.addEventListener('hashchange',()=>{render();page.focus({preventScroll:true});window.scrollTo({top:0,behavior:reducedMotion()?'auto':'smooth'});});
render();
