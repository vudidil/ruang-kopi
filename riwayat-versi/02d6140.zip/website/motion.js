'use strict';
// Gerakan hanya mengubah tampilan angka. Nilai hitungan tetap berasal dari finance.js.
(function(){
 const running=new WeakMap();
 const page=document.querySelector('#page'),curtain=document.querySelector('#scene-curtain'),toggle=document.querySelector('#motion-toggle');
 const media=window.matchMedia('(prefers-reduced-motion: reduce)');
 let preference='full',context=null,observer=null,curtainTween=null,feedbackContext=null,pointerFrame=0,point=null,tilted=null;
 const tiltHandles=new Map();
 try{preference=localStorage.getItem('ruang-kopi-motion')==='light'?'light':'full';}catch(_){}
 const full=()=>preference==='full'&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const capable=()=>full()&&!!window.gsap?.context;
 function syncPreference(){
  const enabled=full();document.body.dataset.motion=enabled?'full':'light';
  document.body.classList.toggle('motion-ready',capable());
  toggle.textContent=enabled?'Gerak penuh':'Gerak ringan';toggle.setAttribute('aria-pressed',String(enabled));
  toggle.disabled=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  toggle.title=toggle.disabled?'Mengikuti pengaturan gerak perangkat':'Ganti intensitas animasi';
 }
 function stopPage(){
  observer?.disconnect();observer=null;context?.revert();context=null;
  curtainTween?.revert();curtainTween=null;feedbackContext?.revert();feedbackContext=null;
  if(pointerFrame)window.cancelAnimationFrame(pointerFrame);pointerFrame=0;point=null;tilted=null;
  tiltHandles.clear();
  curtain.style.visibility='hidden';
 }
 function words(title){
  if(!title)return [];
  if(!title.querySelector('.motion-word')){
   const text=title.textContent;title.setAttribute('aria-label',text);title.textContent='';
   const line=document.createElement('span');line.className='motion-line';line.setAttribute('aria-hidden','true');
   text.split(/(\s+)/).forEach(word=>{if(/^\s+$/.test(word)){line.append(document.createTextNode(word));return;}
    const span=document.createElement('span');span.className='motion-word';span.textContent=word;line.append(span);
   });title.append(line);
  }
  return [...title.querySelectorAll('.motion-word')];
 }
 function wipe(direction,label){
  const g=window.gsap,bands=curtain.querySelectorAll('.scene-band'),title=curtain.querySelector('.scene-label');
  title.textContent=label;curtain.style.visibility='visible';
  curtainTween=g.timeline({onComplete:()=>{curtain.style.visibility='hidden';}});
  curtainTween.fromTo(bands,{x:0,xPercent:-105*direction},{x:0,xPercent:105*direction,duration:.72,stagger:.055,ease:'power3.inOut'},0)
   .fromTo(title,{x:80*direction,y:12,opacity:0},{x:0,y:0,opacity:1,duration:.19,ease:'power2.out'},.16)
   .to(title,{x:-60*direction,y:-35,opacity:0,duration:.22,ease:'power2.in'},.38);
 }
 function enter(root,{animate=true,group=document.body.dataset.page,direction=1}={}){
  stopPage();syncPreference();
  if(!capable()||!animate||root.inert||document.body.classList.contains('intro-active'))return;
  const g=window.gsap,small=window.matchMedia('(max-width: 720px)').matches,distance=small?48:110;
  const profiles={ringkasan:[-distance,0,-2],usaha:[0,75,2],menu:[distance,0,3],hitung:[0,-65,-2],catatan:[-distance,28,0],bantuan:[0,65,0]};
  const [x,y,rotation]=profiles[group]||profiles.ringkasan;
  const title=root.querySelector('h1'),parts=words(title);
  const candidates=[...root.querySelectorAll('.summary-primary .stat,.next-action,.workbook-chart,.stock-notebook,.editor-grid > .panel,.result-column,.lower-grid > .panel,.material-card,.scenario-card,.guide-card,.plan-card')];
  const cards=candidates.filter(el=>!candidates.some(parent=>parent!==el&&parent.contains(el)));
  const revealed=new WeakSet();
  function reveal(elements,delay=0){
   if(!context||!elements.length)return;
   context.add(()=>{
    g.fromTo(elements,{x:i=>(i%2?-x:x)*direction,y,rotation:i=>i%2?-rotation:rotation,scale:.94,opacity:.15},{x:0,y:0,rotation:0,scale:1,opacity:1,duration:.78,delay,stagger:{amount:Math.min(.3,elements.length*.065)},ease:'power3.out',clearProps:'transform,opacity'});
   });elements.forEach(el=>revealed.add(el));
  }
  context=g.context(()=>{
   const tl=g.timeline({defaults:{ease:'power3.out'}});
   tl.fromTo(root.querySelector('.plan-toolbar'),{y:-26,opacity:0},{y:0,opacity:1,duration:.4,clearProps:'transform,opacity'},.12);
   tl.fromTo(parts,{yPercent:110,rotation:7,opacity:0},{yPercent:0,rotation:0,opacity:1,duration:.65,stagger:.045,clearProps:'transform,opacity'},.22);
   const subtitle=root.querySelector('.title-row p');if(subtitle)tl.fromTo(subtitle,{x:-36*direction,opacity:0},{x:0,opacity:1,duration:.5,clearProps:'transform,opacity'},.4);
   const tabs=root.querySelectorAll('.section-tabs a');if(tabs.length)tl.fromTo(tabs,{y:20,opacity:0},{y:0,opacity:1,duration:.35,stagger:.055,clearProps:'transform,opacity'},.35);
   const chartBars=root.querySelectorAll('.chart-track > span');
   if(chartBars.length)tl.fromTo(chartBars,{scaleX:0},{scaleX:(_,el)=>Number(el.style.getPropertyValue('--fill')),duration:.85,stagger:.09,clearProps:'transform'},.5);
  },root);
  // Konten tetap terlihat tanpa IntersectionObserver; gerak tidak menjadi syarat membuka halaman.
  if(window.IntersectionObserver){
   observer=new window.IntersectionObserver(entries=>{const visible=entries.filter(e=>e.isIntersecting&&!revealed.has(e.target)).map(e=>e.target);reveal(visible);visible.forEach(el=>observer?.unobserve(el));},{threshold:.08});
   const initial=cards.filter(el=>el.getBoundingClientRect().top<(window.innerHeight||800));
   reveal(initial,.18);cards.filter(el=>!revealed.has(el)).forEach(el=>observer.observe(el));
  }else reveal(cards,.18);
  const labels={ringkasan:'Rencanamu.',usaha:'Mulai kedaimu.',menu:'Racik menumu.',hitung:'Cek angkanya.',catatan:'Catat harimu.',bantuan:'Satu langkah.'};
  wipe(direction,labels[group]||'Ruang kopi.');
 }
 function feedback(element){
  if(!element||!capable()||document.body.classList.contains('intro-active'))return;
  feedbackContext?.revert();
  feedbackContext=window.gsap.context(()=>{
   // Toast memiliki translateX bawaan untuk pemusatan; gunakan skala agar tidak menggesernya.
   window.gsap.fromTo(element,{scale:.94,opacity:.6},{scale:1,opacity:1,duration:.45,ease:'back.out(1.8)',clearProps:'transform,opacity'});
  });
 }
 function number(element,next,format,previous){
  if(!element)return;
  const active=running.get(element);
  if(active)window.cancelAnimationFrame(active.frame);
  const from=active?.value??previous??Number(element.dataset.value??next);
  element.dataset.value=String(next);
  element.setAttribute('aria-label',format(next));
  const finish=()=>{element.textContent=format(next);running.delete(element);};
  if(from===next||!Number.isFinite(from)||!full()||!window.requestAnimationFrame){finish();return;}
  const state={value:from,frame:0,start:null};running.set(element,state);
  const tick=time=>{
   if(!element.isConnected){running.delete(element);return;}
   if(!full()){finish();return;}
   if(state.start===null)state.start=time;
   const progress=Math.min(1,(time-state.start)/320);
   state.value=from+(next-from)*(1-Math.pow(1-progress,3));element.textContent=format(state.value);
   if(progress<1)state.frame=window.requestAnimationFrame(tick);else finish();
  };
  state.frame=window.requestAnimationFrame(tick);
 }
 toggle.addEventListener('click',()=>{
  preference=preference==='full'?'light':'full';
  try{localStorage.setItem('ruang-kopi-motion',preference);}catch(_){}
  stopPage();syncPreference();if(capable())enter(page);
 });
 media.addEventListener?.('change',()=>{stopPage();syncPreference();});
 document.addEventListener('rk:intro-start',stopPage);
 document.addEventListener('rk:intro-end',()=>enter(page));
 document.addEventListener('visibilitychange',()=>{if(document.hidden)stopPage();});
 document.addEventListener('focusin',event=>{
  if(event.target===page||!page.contains(event.target)||!context)return;
  // Keyboard tidak perlu menunggu kontrol yang sedang masuk dari luar layar.
  stopPage();
 });
 page.addEventListener('pointermove',event=>{
  if(!capable()||!context||event.pointerType!=='mouse'||!window.matchMedia('(hover: hover) and (pointer: fine)').matches)return;
  const card=event.target.closest('.profit-feature,.next-action');if(!card)return;
  point={card,x:event.clientX,y:event.clientY};if(pointerFrame)return;
  pointerFrame=window.requestAnimationFrame(()=>{
   pointerFrame=0;if(!point||!context)return;
   const {card,x,y}=point,rect=card.getBoundingClientRect();if(!rect.width||!rect.height)return;
   if(!tiltHandles.has(card))context.add(()=>{
    window.gsap.set(card,{transformPerspective:900});
    tiltHandles.set(card,{x:window.gsap.quickTo(card,'rotationX',{duration:.35,ease:'power2.out'}),y:window.gsap.quickTo(card,'rotationY',{duration:.35,ease:'power2.out'})});
   });
   tilted=card;const handles=tiltHandles.get(card);handles.x(((y-rect.top)/rect.height-.5)*-6);handles.y(((x-rect.left)/rect.width-.5)*8);
  });
 });
 page.addEventListener('pointerout',event=>{
  if(point&&!point.card.contains(event.relatedTarget)){
   if(pointerFrame)window.cancelAnimationFrame(pointerFrame);pointerFrame=0;point=null;
  }
  if(tilted&&!tilted.contains(event.relatedTarget)&&context){const handles=tiltHandles.get(tilted);tilted=null;handles?.x(0);handles?.y(0);}
 });
 syncPreference();
 window.RKMotion={number,enter,stopPage,feedback};
})();
