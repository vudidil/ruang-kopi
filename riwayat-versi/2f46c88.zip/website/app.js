'use strict';
// Tampilan dan interaksi. Rumus utama berada di finance.js.
const {uid,today,createPlan,recipeCost,menuChannel,calculate,validatePlan}=window.RK;
const money=n=>new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n);
const integer=n=>new Intl.NumberFormat('id-ID',{maximumFractionDigits:2}).format(n);
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const reducedMotion=()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches;
let storageOK=true,firstVisit=false,undoAction=null,toastTimer;
let store;
try {
 const saved=JSON.parse(localStorage.getItem('ruang-kopi-v3'));
 if(saved&&saved.version===3&&Array.isArray(saved.plans)&&saved.plans.length>0&&saved.plans.length<=20&&saved.plans.every(validatePlan))store=saved;
 else {
   const old=JSON.parse(localStorage.getItem('ruang-kopi-v1'));
   if(old&&Array.isArray(old.capital)&&Array.isArray(old.ingredients)){
     const migrated=window.RK.migrate(old);
     if(validatePlan(migrated))store={version:3,activeId:migrated.id,plans:[migrated]};
   }
 }
} catch(_){storageOK=false;}
if(!store){const p=createPlan(false);store={version:3,activeId:p.id,plans:[p]};firstVisit=true;}
if(!store.plans.some(p=>p.id===store.activeId))store.activeId=store.plans[0].id;
const plan=()=>store.plans.find(p=>p.id===store.activeId);
let selectedMenu='',opsMonth=today().slice(0,7),selectedChannel='dinein';
const iconPaths = {
  grid:'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  wallet:'<path d="M20 8V5a2 2 0 0 0-2-2L5 6a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h15V8H5"/><path d="M20 12h-5v5h5"/><path d="M16 14.5h.1"/>',
  coffee:'<path d="M4 8h13v7a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5V8Zm13 1h2a3 3 0 0 1 0 6h-2M7 3v2m4-2v2m4-2v2M3 22h16"/>',
  chart:'<path d="M4 3v17h17M8 15v-4m5 4V7m5 8V4"/>',
  target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  arrow:'<path d="M5 12h14m-5-5 5 5-5 5"/>',
  back:'<path d="M19 12H5m5-5-5 5 5 5"/>',
  diagonal:'<path d="M6 18 18 6M7 6h11v11"/>',
  download:'<path d="M12 3v12m-4-4 4 4 4-4M4 16v4h16v-4"/>',
  spark:'<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  trash:'<path d="M4 6h16M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7m4-7v7"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/>',
  leaf:'<path d="M5 19C-1 6 12 3 21 3c0 12-5 18-13 15M4 21 16 9"/>'
};
function icon(name) { return '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">'+(iconPaths[name] || iconPaths.spark)+'</svg>'; }
document.querySelectorAll('[data-icon]').forEach(el => el.insertAdjacentHTML('afterbegin', icon(el.dataset.icon)));

const titles={
 ringkasan:['Racik rencana kedaimu.','Satu ruang untuk melihat angka dan menentukan langkah.','Ringkasan','grid'],
 profil:['Kedai ini punya ceritamu.','Mulai dari nama, konsep, dan hari pembukaan.','Profil kedai','leaf'],
 modal:['Modal cukup, langkah tenang.','Pisahkan biaya pembukaan dan uang cadangan.','Modal & cadangan','wallet'],
 hpp:['Kenali setiap racikan.','Harga bahan dan takaran resep menentukan biaya per cup.','Menu & resep','coffee'],
 omzet:['Coba berbagai kemungkinan.','Bandingkan menu, cara penjualan, dan kondisi kedai.','Penjualan & skenario','chart'],
 laba:['Pahami arti angkanya.','Lihat keuntungan, titik impas, dan langkah yang bisa dicoba.','Laba & BEP','target'],
 operasional:['Catat yang benar-benar terjadi.','Penjualan, pengeluaran, pembelian, dan bahan terbuang.','Catatan usaha','grid'],
 rencana:['Simpan ide, bandingkan pilihan.','Buat beberapa rencana dan backup agar bisa dipulihkan.','Rencana & backup','wallet'],
 panduan:['Belajar sambil merencanakan.','Penjelasan singkat dengan bahasa sehari-hari.','Panduan singkat','info']
};
const page=document.querySelector('#page'),channelNames={dinein:'Di tempat',takeaway:'Bawa pulang',delivery:'Delivery'};
function route(){return Object.hasOwn(titles,location.hash.slice(1))?location.hash.slice(1):'ringkasan';}
function getPath(obj,path){return path.split('.').reduce((v,k)=>v?.[k],obj);}
function setPath(obj,path,value){const parts=path.split('.'),key=parts.pop();parts.reduce((v,k)=>v[k],obj)[key]=value;}
function save(){
 try{localStorage.setItem('ruang-kopi-v3',JSON.stringify(store));storageOK=true;}catch(_){storageOK=false;}
 document.querySelector('#save-status').innerHTML='<span class="live-dot"></span>'+(storageOK?'Tersimpan di perangkat':'Gagal menyimpan · unduh backup');
}
function notify(message,undo=null){
 clearTimeout(toastTimer);undoAction=undo;
 const el=document.querySelector('#toast');el.innerHTML=icon('check')+'<span>'+esc(message)+'</span>'+(undo?'<button id="undo">Urungkan</button>':'');
 el.classList.add('show');toastTimer=setTimeout(()=>{el.classList.remove('show');undoAction=null;},undo?9000:4000);
}
function field(path,label,opts={}){
 const val=getPath(plan(),path),type=opts.type||'number',step=opts.step??(path.endsWith('days')||path.endsWith('cups')||path.endsWith('baristas')?1:'any');
 return '<label class="field"><span>'+label+'</span><input class="input" type="'+type+'" data-path="'+path+'" value="'+esc(val)+'" '+(type==='number'?'min="'+(opts.min??0)+'" max="'+(opts.max??1e12)+'" step="'+step+'"':'maxlength="'+(opts.maxlength||100)+'"')+' aria-describedby="err-'+path.replaceAll('.','-')+'"><span class="error-text" id="err-'+path.replaceAll('.','-')+'"></span></label>';
}
function listField(type,i,key,label,opts={}){
 return field(type+'.'+i+'.'+key,label,opts);
}
const head=(label)=>'<div class="result-label">'+label+'<span class="live-pill">LIVE</span></div>';
const row=(label,value)=>'<div class="breakdown"><span>'+label+'</span><b>'+value+'</b></div>';
const big=value=>'<strong class="big">'+money(value)+'</strong>';
const helper=text=>'<p class="helper">'+icon('info')+text+'</p>';
function distribution(){
 const p=plan(),c=calculate(p),list=[...p.capital,{name:'Cadangan kas',cost:p.reserve}],colors=['#c1eca2','#c1b4ee','#ffd7a8','#96d8da','#edf6cd','#e5b6c8'];
 if(c.capital===0)return '<p>Tambahkan kebutuhan pembukaan untuk melihat komposisi modal.</p>';
 return '<div class="distribution">'+list.map((x,i)=>'<span style="flex:'+x.cost+';background:'+colors[i%colors.length]+'"></span>').join('')+'</div>'+list.map((x,i)=>'<div class="legend"><span class="legend-label"><span class="swatch" style="background:'+colors[i%colors.length]+'"></span>'+esc(x.name)+'</span><b>'+integer(x.cost/c.capital*100)+'%</b></div>').join('');
}
function advice(c=calculate(plan())){
 const p=plan(),messages=[];
 if(p.menus.some(m=>m.mix>0&&(!m.recipe.some(r=>r.qty>0)||m.recipe.some(r=>p.ingredients.find(i=>i.id===r.ingredientId)?.packPrice===0))))messages.push({tone:'warn',title:'Ada resep yang belum lengkap',text:'Isi takaran dan harga beli bahan untuk semua menu aktif. Biaya nol yang belum diisi bisa membuat laba terlihat terlalu tinggi.',href:'#hpp'});
 if(!c.valid)messages.push({tone:'warn',title:'Lengkapi campuran penjualan',text:'Tambahkan menu dengan bobot lebih dari nol dan aktifkan setidaknya satu cara penjualan.',href:'#hpp'});
 else if(c.bepDaily===null)messages.push({tone:'warn',title:'Biaya belum tertutup',text:'Rata-rata pendapatan per cup belum melebihi biaya variabel. Tinjau harga jual, resep, atau komisi.',href:'#hpp'});
 else if(c.profit<0)messages.push({tone:'warn',title:'Target masih di bawah titik impas',text:'Targetmu '+integer(p.assumptions.cups)+' cup/hari. Perlu sekitar '+integer(c.bepDaily)+' cup/hari agar biaya yang dimasukkan tertutup.',href:'#omzet'});
 else messages.push({tone:'good',title:'Target sudah melewati titik impas',text:'Dengan asumsi sekarang, estimasi laba '+money(c.profit)+'/bulan. Ini proyeksi sebelum pajak dan penyusutan.',href:'#laba'});
 if(c.shortfall>0)messages.push({tone:'warn',title:'Dana pembukaan masih kurang',text:'Tambahan '+money(c.shortfall)+' dibutuhkan agar biaya pembukaan dan target cadangan terpenuhi.',href:'#modal'});
 if(c.capacity>0&&p.assumptions.cups>c.capacity)messages.push({tone:'warn',title:'Target melebihi kapasitas perkiraan',text:'Kapasitas tim sekitar '+integer(c.capacity)+' cup/hari. Periksa jumlah barista, jam kerja, dan peralatannya.',href:'#omzet'});
 if(p.assumptions.days===0)messages.push({tone:'warn',title:'Hari buka belum diisi',text:'Isi hari operasional untuk menghitung penjualan bulanan dan target impas harian.',href:'#omzet'});
 return messages;
}
function adviceCards(){return advice().map(a=>'<a class="advice '+a.tone+'" href="'+a.href+'"><span class="advice-symbol">'+icon(a.tone==='good'?'check':'info')+'</span><div><strong>'+a.title+'</strong><p>'+a.text+'</p></div>'+icon('arrow')+'</a>').join('');}
function stat(label,value,note,href,ico){return '<a class="stat" href="'+href+'"><div class="stat-top"><span class="stat-icon">'+icon(ico)+'</span><span class="stat-arrow">'+icon('diagonal')+'</span></div><span class="stat-label">'+label+'</span><strong>'+value+'</strong><small>'+note+'</small></a>';}
function slider(){const a=plan().assumptions,max=Math.max(200,a.cups);return '<input id="sales-slider" class="range" aria-label="Target cup per hari" type="range" min="0" max="'+max+'" step="1" data-path="assumptions.cups" value="'+a.cups+'" style="--range:'+(a.cups/max*100)+'%"><div class="range-labels"><span>0 cup</span><span>'+integer(max)+' cup/hari</span></div>';}
function welcome(){return '<section class="panel welcome"><div><div class="eyebrow">MULAI DARI SINI</div><h2>Pilih cara memulai rencanamu.</h2><p>Contoh membantu belajar. Rencana kosong siap diisi dengan angka milikmu sendiri.</p></div><div class="button-group"><button class="primary" data-action="start-sample">Pakai contoh kedai</button><button data-action="start-blank">Mulai dari kosong</button></div></section>';}
function overview(){
 const p=plan(),c=calculate(p);
 return (firstVisit?welcome():'')+'<section class="hero"><div class="hero-content"><div class="hero-kicker">'+icon('spark')+' DARI IDE, JADI KEDAI.</div><h2>Racik kopimu.<br>Rencanakan <em>mimpimu.</em></h2><p>'+esc(p.profile.name||'Kedai impianmu')+' tumbuh dari keputusan kecil yang kamu pahami. Mulai dari resep, lalu temukan angka yang masuk akal.</p><div class="hero-actions"><a class="button" href="#hpp">Racik menu pertama '+icon('arrow')+'</a><a class="text-link" href="#modal">Hitung modal '+icon('diagonal')+'</a></div></div><div class="hero-art" aria-hidden="true"><div class="orb orb-one"></div><div class="orb orb-two"></div><div class="cup-scene"><div class="cup-shadow"></div><div class="cup-body"><div class="cup-sleeve">rk.<small>BREW YOUR DREAM</small></div></div><div class="cup-lid"></div></div><div class="floating-tag tag-one"><small>LANGKAH KECIL HARI INI.</small><b>Your next chapter.</b></div><div class="floating-tag tag-two">'+icon('check')+'Ide bagus. Rencana matang.</div></div></section>'+
 '<div class="section-heading"><h2>Gambaran rencanamu</h2><small>SIMULASI · BUKAN PENJUALAN AKTUAL</small></div><div class="stats">'+stat('Total modal',money(c.capital),'Termasuk target cadangan','#modal','wallet')+stat('Biaya variabel / cup',money(c.variable),'Resep, kemasan & biaya penjualan','#hpp','coffee')+stat('Omzet bersih bulanan',money(c.revenue),'Setelah diskon, sebelum komisi','#omzet','chart')+stat('Estimasi laba bulanan',money(c.profit),'Sebelum pajak & penyusutan','#laba','target')+'</div>'+
 '<div class="lower-grid"><section class="panel"><div class="panel-heading"><div><h2>Langkah yang bisa kamu ambil</h2><p>Penjelasan berdasarkan angka rencanamu.</p></div></div><div id="advice-list">'+adviceCards()+'</div></section><section class="panel sim-panel"><div class="panel-heading"><div><h2>Bagaimana jika…</h2><p>Geser target dan lihat perubahan omzet.</p></div><span class="stat-icon">'+icon('spark')+'</span></div><div class="sim-value"><b id="cup-output">'+integer(p.assumptions.cups)+'</b><span>cup terjual setiap hari</span></div>'+slider()+'<div class="sim-bottom"><div><small>Omzet bersih per bulan</small><strong id="sim-revenue">'+money(c.revenue)+'</strong></div><a href="#omzet">Bandingkan skenario '+icon('arrow')+'</a></div></section></div>'+
 '<div class="tip-strip">'+icon('info')+'<p>Masih bingung? <b>HPP, omzet, laba, kas, dan BEP</b> dijelaskan dengan contoh sederhana.</p><a href="#panduan">Buka panduan ↗</a></div>';
}
function profilePage(){
 return '<div class="editor-grid"><section class="panel"><div class="editor-heading"><span class="stat-icon">'+icon('leaf')+'</span><div><h2>Identitas kedaimu</h2><p>Rencana lebih personal, tujuan lebih jelas.</p></div></div>'+field('profile.name','Nama coffee shop',{type:'text'})+field('profile.concept','Konsep usaha',{type:'text',maxlength:300})+field('profile.opening','Target pembukaan',{type:'date'})+helper('Tanggal ini adalah target pribadi, bukan jadwal pengingat otomatis.')+'</section><section class="panel tip"><div class="eyebrow">IDE UNTUK KONSEPMU</div><h3>Kedai kecil.<br>Cerita yang besar.</h3><p>Contoh konsep: booth takeaway dekat sekolah, kedai tenang untuk belajar, atau coffee shop kecil di lingkungan rumah.</p><a href="#modal">Lanjut hitung kebutuhan modal →</a></section></div>';
}
function capitalPage(){
 const p=plan();return '<div class="editor-grid"><section class="panel"><div class="editor-heading"><span class="stat-icon">'+icon('wallet')+'</span><div><h2>Kebutuhan sebelum buka</h2><p>Masukkan aset, renovasi, dan stok awal.</p></div></div><div class="capital-rows">'+p.capital.map((x,i)=>'<div class="capital-row">'+listField('capital',i,'name','Komponen '+(i+1),{type:'text'})+listField('capital',i,'cost','Biaya (Rp)')+'<button class="delete-button" data-action="remove-capital" data-index="'+i+'" aria-label="Hapus '+esc(x.name)+'">'+icon('trash')+'</button></div>').join('')+(!p.capital.length?'<p class="empty-state">Belum ada kebutuhan. Mulai dengan menambah komponen.</p>':'')+'</div><button class="add-button" data-action="add-capital">'+icon('plus')+' Tambah kebutuhan</button><div class="divider"></div><div class="field-grid">'+field('funds','Uang yang kamu miliki (Rp)')+field('reserve','Target cadangan kas (Rp)')+'</div>'+helper('Cadangan kas diisi di kolom ini saja. Jangan masukkan lagi sebagai komponen kebutuhan agar tidak terhitung dua kali.')+'</section><div class="result-column"><section class="panel result" id="result">'+capitalResult()+'</section><p class="result-note">Sisa kas setelah pembukaan = uang tersedia − biaya pembukaan. Perhitungan daya tahan di sini mengasumsikan tidak ada penjualan dan hanya membayar biaya tetap.</p><a class="button" href="#laba">Atur biaya bulanan '+icon('arrow')+'</a></div></div>';
}
function capitalResult(){
 const c=calculate(plan());
 return head('TOTAL KEBUTUHAN DANA')+big(c.capital)+row('Biaya pembukaan',money(c.setup))+row('Target cadangan',money(plan().reserve))+'<div class="divider"></div>'+row('Uang tersedia',money(plan().funds))+row(c.shortfall>0?'Kekurangan dana':'Dana di atas target',money(c.shortfall>0?c.shortfall:plan().funds-c.capital))+distribution()+'<div class="result-bottom"><b>Sisa kas setelah pembukaan: '+money(c.cash)+'.</b><br>'+(plan().funds<c.setup?'Dana belum cukup untuk biaya pembukaan.':c.runway===null?'Isi biaya tetap bulanan untuk menghitung daya tahan kas.':'Tanpa penjualan, cukup sekitar '+integer(c.runway)+' bulan untuk biaya tetap yang diisi.')+'</div>';
}
function menuPage(){
 const p=plan();if(!p.menus.some(m=>m.id===selectedMenu))selectedMenu=p.menus[0]?.id||'';
 const mi=p.menus.findIndex(m=>m.id===selectedMenu),m=p.menus[mi];
 let content='<div class="panel-heading"><div><h2>Daftar menu</h2><p>Bobot menentukan perbandingan jumlah cup yang terjual.</p></div><button data-action="add-menu">'+icon('plus')+' Menu baru</button></div>';
 content+='<div class="menu-tabs">'+p.menus.map(x=>'<button data-action="select-menu" data-id="'+x.id+'" aria-pressed="'+(x.id===selectedMenu)+'">'+esc(x.name||'Menu baru')+'</button>').join('')+'</div>';
 if(m){
   content+='<div class="field-grid">'+listField('menus',mi,'name','Nama menu',{type:'text'})+listField('menus',mi,'mix','Bobot penjualan',{max:10000})+'</div><div class="field-grid three">'+['dinein','takeaway','delivery'].map(k=>listField('menus',mi,'prices.'+k,'Harga '+channelNames[k]+' (Rp)')).join('')+'</div><div class="divider"></div><h2>Takaran untuk satu cup</h2><div class="recipe-rows">'+m.recipe.map((r,i)=>{const ingredient=p.ingredients.find(x=>x.id===r.ingredientId);return '<div class="recipe-row"><label class="field"><span>Bahan</span><select class="input" data-path="menus.'+mi+'.recipe.'+i+'.ingredientId">'+p.ingredients.map(x=>'<option value="'+x.id+'" '+(r.ingredientId===x.id?'selected':'')+'>'+esc(x.name)+' ('+x.unit+')</option>').join('')+'</select></label>'+field('menus.'+mi+'.recipe.'+i+'.qty','Pemakaian ('+(ingredient?.unit||'')+')')+'<button class="delete-button" data-action="remove-recipe" data-index="'+i+'" aria-label="Hapus bahan dari resep">'+icon('trash')+'</button></div>';}).join('')+'</div><button class="add-button" data-action="add-recipe">'+icon('plus')+' Tambah bahan ke resep</button>'+helper('Contoh: susu Rp20.000 per 1.000 ml, dipakai 125 ml → biaya susu Rp2.500/cup. Angka HPP di kanan mencakup waste sesuai pengaturan penjualan.')+'<button class="danger-text" data-action="remove-menu">Hapus menu ini</button>';
 }else content+='<p class="empty-state">Tambahkan menu pertama untuk mulai menyusun resep.</p>';
 return '<div class="editor-grid"><section class="panel">'+content+'</section><div class="result-column"><section class="panel result" id="result">'+menuResult()+'</section><p class="result-note">Harga jual berbeda untuk di tempat, bawa pulang, dan delivery. Kemasan, waste, diskon, dan biaya penjualan diatur pada halaman Penjualan & skenario.</p></div></div><section class="panel ingredients-panel"><div class="panel-heading"><div><h2>Harga beli bahan</h2><p>Gunakan satuan g, ml, atau pcs. Contoh: 1 kg = 1.000 g.</p></div><button data-action="add-ingredient">'+icon('plus')+' Bahan baru</button></div>'+(!p.ingredients.length?'<p class="empty-state">Tambahkan bahan sebelum menyusun resep.</p>':'')+'<div class="ingredient-grid">'+p.ingredients.map((x,i)=>'<div class="ingredient-card">'+listField('ingredients',i,'name','Nama bahan',{type:'text'})+'<div class="field-grid">'+listField('ingredients',i,'packPrice','Harga beli (Rp)')+listField('ingredients',i,'packQty','Isi kemasan',{min:.001})+'</div><label class="field"><span>Satuan isi & pemakaian</span><select class="input" data-path="ingredients.'+i+'.unit" '+(p.menus.some(m=>m.recipe.some(r=>r.ingredientId===x.id))||p.ledger.some(e=>e.movements.some(m=>m.id===x.id))?'disabled title="Satuan dikunci karena bahan sudah dipakai"':'')+'>'+['g','ml','pcs'].map(u=>'<option '+(x.unit===u?'selected':'')+'>'+u+'</option>').join('')+'</select></label><button class="danger-text" data-action="remove-ingredient" data-index="'+i+'">Hapus bahan</button></div>').join('')+'</div></section>';
}
function menuResult(){
 const p=plan(),m=p.menus.find(x=>x.id===selectedMenu);
 if(!m)return head('HPP RESEP')+'<p>Tambahkan menu dan resep untuk mulai menghitung.</p>';
 const base=recipeCost(p,m),food=base/(1-p.assumptions.waste/100);
 return head('HPP RESEP · '+esc(m.name))+big(food)+row('Bahan sesuai takaran',money(base))+row('Tambahan akibat waste',money(food-base))+'<div class="divider"></div>'+Object.keys(channelNames).map(k=>{const v=menuChannel(p,m,k);return '<div class="mini-result"><strong>'+channelNames[k]+'</strong>'+row('Biaya variabel / cup',money(v.variable))+row('Kontribusi / cup',money(v.contribution))+'</div>';}).join('')+'<div class="result-bottom">Kontribusi = pendapatan setelah diskon − bahan, kemasan, dan biaya penjualan. Ini belum laba bersih.</div>';
}
function scenarioTable(){
 const p=plan(),normal=p.assumptions.cups,counts=[Math.round(normal*.5),normal,Math.round(normal*1.5)];
 return '<div class="scenario-grid">'+counts.map((cups,i)=>{const c=calculate(p,cups);return '<div class="scenario-card '+(i===1?'current':'')+'"><span class="eyebrow">'+['SEPI · 50%','TARGETMU · 100%','RAMAI · 150%'][i]+'</span><h3>'+integer(cups)+' <small>cup/hari</small></h3><p>Omzet / bulan</p><strong>'+money(c.revenue)+'</strong><p>'+(c.profit<0?'Rugi':'Laba')+' / bulan</p><strong class="'+(c.profit<0?'negative':'positive')+'">'+money(c.profit)+'</strong>'+((c.capacity>0&&cups>c.capacity)?'<small class="capacity-warn">Melebihi kapasitas perkiraan</small>':'')+'</div>';}).join('')+'</div><p class="helper">Semua skenario memakai campuran menu, harga, hari buka, dan biaya yang sama. Ramai bukan jaminan laba.</p>';
}
function salesPage(){
 const p=plan();
 return '<div class="editor-grid"><section class="panel"><div class="editor-heading"><span class="stat-icon">'+icon('chart')+'</span><div><h2>Target & kapasitas</h2><p>Geser slider atau isi angka sendiri.</p></div></div><div class="field-grid">'+field('assumptions.cups','Target cup per hari',{step:1})+field('assumptions.days','Hari buka per bulan',{max:31,step:1})+'</div>'+slider()+'<div class="divider"></div><div class="field-grid">'+field('assumptions.hours','Jam buka per hari',{max:24})+field('assumptions.baristas','Barista aktif bersamaan',{step:1})+field('assumptions.cupsPerBarista','Kemampuan cup/barista/jam')+'</div>'+helper('Kapasitas = jam buka × barista aktif × cup per jam. Ini perkiraan; antrean, istirahat, dan alat dapat mengurangi hasil.')+'<div class="divider"></div><h2>Biaya yang sering terlupa</h2><div class="field-grid spaced">'+field('assumptions.waste','Waste bahan (%)',{max:95})+field('assumptions.discount','Diskon rata-rata (%)',{max:100})+field('assumptions.paymentFee','Biaya pembayaran rata-rata (%)',{max:100})+'</div>'+helper('Waste 5% berarti hanya 95% bahan terbeli dapat dipakai. Biaya pembayaran diisi rata-rata seluruh penjualan; komisi delivery diatur terpisah.')+'</section><div class="result-column"><section class="panel result" id="result">'+salesResult()+'</section><div id="sales-advice" class="spaced">'+adviceCards()+'</div></div></div>'+
 '<section class="panel spaced"><div class="panel-heading"><div><h2>Cara pelanggan membeli</h2><p>Bobot dinormalisasi. Contoh 40 : 40 : 20 berarti 40%, 40%, 20%.</p></div></div><div class="channel-grid">'+Object.keys(channelNames).map(k=>'<div class="ingredient-card"><h2>'+channelNames[k]+'</h2>'+field('channels.'+k+'.share','Bobot kanal',{max:100})+field('channels.'+k+'.packaging','Kemasan per cup (Rp)')+field('channels.'+k+'.fee','Komisi kanal (%)',{max:100})+'</div>').join('')+'</div></section>'+
 '<section class="panel spaced"><div class="panel-heading"><div><h2>Bandingkan tiga kemungkinan</h2><p>Jumlah cup menjadi 50%, 100%, dan 150% targetmu.</p></div></div><div id="scenario-table">'+scenarioTable()+'</div></section>';
}
function salesResult(){
 const p=plan(),c=calculate(p);
 return head('OMZET BERSIH BULANAN')+big(c.revenue)+row('Cup terjual / bulan',integer(c.units))+row('Harga rata-rata sebelum diskon',money(c.price))+row('Pendapatan rata-rata / cup',money(c.net))+row('Kapasitas perkiraan / hari',c.capacity>0?integer(c.capacity)+' cup':'Belum diisi')+'<div class="result-bottom">Omzet bersih di sini sudah dikurangi diskon, tetapi belum dikurangi komisi, kemasan, dan biaya lainnya.</div>';
}
function profitPage(){
 return '<div class="editor-grid"><section class="panel"><div class="editor-heading"><span class="stat-icon">'+icon('target')+'</span><div><h2>Biaya tetap setiap bulan</h2><p>Catat kebutuhan rutin yang harus dibayar.</p></div></div><div class="field-grid">'+field('fixed.rent','Sewa tempat (Rp)')+field('fixed.salary','Gaji tim (Rp)')+field('fixed.utilities','Listrik, air & internet (Rp)')+field('fixed.other','Biaya tetap lainnya (Rp)')+'</div><div class="divider"></div><h2>Arti hasilnya untuk kedaimu</h2><div id="profit-advice" class="spaced">'+adviceCards()+'</div><div class="button-group spaced"><a class="button" href="#hpp">Ubah harga & resep</a><a class="button" href="#omzet">Ubah penjualan</a></div></section><div class="result-column"><section class="panel result" id="result">'+profitResult()+'</section><details class="formula"><summary>Cara menghitung BEP '+icon('arrow')+'</summary><p>BEP cup = biaya tetap ÷ kontribusi rata-rata per cup, dibulatkan ke atas. Rata-rata mengikuti bobot menu dan cara penjualan. BEP bukan waktu balik modal.</p></details><p class="result-note">Laba simulasi belum mencakup pajak, penyusutan aset, cicilan pokok, bunga, atau biaya yang belum kamu masukkan. Sisa kas tidak sama dengan laba.</p></div></div>';
}
function profitResult(){
 const p=plan(),c=calculate(p);
 return head(c.profit<0?'ESTIMASI RUGI BULANAN':'ESTIMASI LABA BULANAN')+big(c.profit)+row('Omzet setelah diskon',money(c.revenue))+row('Seluruh biaya variabel',money(c.cost))+row('Biaya tetap',money(c.fixed))+'<div class="divider"></div>'+row('Kontribusi rata-rata / cup',money(c.contribution))+row('BEP per bulan',c.bep===null?'Belum tercapai':integer(c.bep)+' cup')+row('Target impas per hari',c.bepDaily===null?'Belum tersedia':integer(c.bepDaily)+' cup')+'<div class="result-bottom">'+(c.profit<0?'Jika hasil dan biaya kas mengikuti simulasi ini, sisa kas '+money(c.cash)+' dapat menutup kerugian sekitar <b>'+integer(c.lossRunway)+' bulan</b>.':'Laba positif belum berarti modal sudah kembali. Pantau arus kas aktual sebelum menilai waktu balik modal.')+'</div>';
}
function plansPage(){
 return '<section class="panel"><div class="panel-heading"><div><h2>Semua rencana usaha</h2><p>Maksimal 20 rencana. Setiap rencana memiliki resep, stok, dan catatannya sendiri.</p></div><div class="button-group"><button data-action="new-blank">'+icon('plus')+' Rencana kosong</button><button data-action="new-sample">Tambah contoh</button></div></div><div class="plan-grid">'+store.plans.map(p=>{const c=calculate(p);return '<article class="plan-card '+(p.id===store.activeId?'selected':'')+'"><span class="chip">'+(p.example?'DATA CONTOH':p.id===store.activeId?'SEDANG DIBUKA':'RENCANA TERSIMPAN')+'</span><h3>'+esc(p.name)+'</h3><p>'+esc(p.profile.name||'Nama kedai belum diisi')+'</p><div class="plan-metrics"><span>Modal <b>'+money(c.capital)+'</b></span><span>Laba/bulan <b>'+money(c.profit)+'</b></span></div><div class="button-group"><button data-action="open-plan" data-id="'+p.id+'">Buka</button><button data-action="duplicate-plan" data-id="'+p.id+'">Salin</button><button class="danger-text" data-action="delete-plan" data-id="'+p.id+'" '+(store.plans.length===1?'disabled':'')+'>Hapus</button></div></article>';}).join('')+'</div></section><section class="panel spaced"><h2>Nama rencana yang sedang dibuka</h2><div class="spaced">'+field('name','Nama rencana',{type:'text'})+'</div>'+helper('Nama rencana bisa berbeda dari nama kedai. Contoh: “Booth dekat sekolah” dan “Kedai dengan tempat duduk”.')+'</section><section class="panel spaced"><div class="panel-heading"><div><h2>Backup & pindah perangkat</h2><p>Unduh file JSON untuk menyimpan seluruh rencana dan catatan usaha.</p></div></div><div class="button-group"><button class="primary" data-action="backup">'+icon('download')+' Unduh backup JSON</button><label class="button file-label">Pulihkan dari file<input id="import-file" type="file" accept=".json,application/json"></label></div>'+helper('Impor menambahkan salinan rencana dari backup, tanpa menimpa rencana yang sudah ada. Data tetap disimpan di browser; penghapusan data browser dapat menghapusnya.')+'</section>';
}
function guidePage(){
 return '<section class="panel"><h2>Mulai dari enam langkah sederhana</h2><div class="guide-grid">'+[
 ['01','Kenalkan kedaimu','Isi nama dan konsep usaha agar rencanamu punya tujuan.','#profil'],
 ['02','Hitung uang pembukaan','Masukkan kebutuhan, uang tersedia, dan target cadangan kas.','#modal'],
 ['03','Susun racikan','Isi harga bahan per kemasan, takaran setiap cup, dan harga tiap menu.','#hpp'],
 ['04','Coba penjualan','Atur bobot menu dan kanal, lalu bandingkan kondisi sepi hingga ramai.','#omzet'],
 ['05','Periksa hasil','Baca laba dan BEP, kemudian sesuaikan rencana bila biayanya belum tertutup.','#laba'],
 ['06','Simpan & mulai mencatat','Backup rencanamu. Setelah usaha berjalan, catat transaksi aktual.','#rencana']
 ].map(x=>'<a class="guide-card" href="'+x[3]+'"><span class="step-number">'+x[0]+'</span><h3>'+x[1]+'</h3><p>'+x[2]+'</p></a>').join('')+'</div></section><section class="panel spaced"><h2>Kamus kecil pemilik kedai</h2><div class="glossary">'+[
 ['HPP resep','Biaya bahan untuk satu cup. Susu Rp20.000/1.000 ml × pemakaian 125 ml = Rp2.500. Aplikasi menambahkan waste jika diisi.'],
 ['Biaya variabel','Biaya yang bertambah saat penjualan bertambah: bahan, kemasan, komisi, dan biaya pembayaran.'],
 ['Bobot penjualan','Perbandingan penjualan. Kopi susu 60 dan Americano 40 berarti perkiraan 60% dan 40% cup. Tidak harus berjumlah 100; sistem menghitung proporsinya.'],
 ['Omzet bersih','Total penjualan setelah diskon. Uang ini belum seluruhnya menjadi keuntungan.'],
 ['Kontribusi','Pendapatan setelah diskon dikurangi biaya variabel. Sisanya untuk menutup sewa, gaji, dan biaya tetap lain.'],
 ['Laba','Omzet dikurangi biaya variabel serta biaya tetap yang dimasukkan. Laba simulasi di aplikasi ini sebelum pajak dan penyusutan.'],
 ['BEP / titik impas','Jumlah cup minimum agar biaya yang dimasukkan tertutup. Ini berbeda dengan waktu balik modal.'],
 ['Kas & cadangan','Uang yang tersedia untuk membayar kebutuhan. Pembelian mesin mengurangi kas, tetapi bukan seluruhnya beban bulan pertama.'],
 ['Simulasi dan aktual','Simulasi adalah perkiraan. Catatan usaha adalah transaksi yang kamu masukkan setelah benar-benar terjadi. Keduanya tidak dijumlahkan.'],
 ['Panel operasional lokal','Halaman Catatan usaha mengelola transaksi dan stok di browser. Belum ada akun tim, izin kasir, atau sinkronisasi server.']
 ].map(x=>'<details class="formula"><summary>'+x[0]+icon('arrow')+'</summary><p>'+x[1]+'</p></details>').join('')+'</div></section>';
}
function entryField(name,label,type='number',value='',extra=''){
 return '<label class="field"><span>'+label+'</span><input class="input" name="'+name+'" type="'+type+'" value="'+esc(value)+'" '+(type==='number'?'min="0" max="1000000000000" step="any"':'maxlength="300"')+' '+extra+' required></label>';
}
function operationsPage(){
 const p=plan(),entries=p.ledger.filter(e=>e.date.startsWith(opsMonth)),revenue=entries.reduce((s,e)=>s+e.revenue,0),cost=entries.reduce((s,e)=>s+e.cost,0);
 return '<div class="notice">'+icon('info')+'<p><b>Catatan aktual di browser ini.</b> Terpisah dari simulasi. Belum ada akun tim atau sinkronisasi server. Backup mencakup catatan ini.</p></div><section class="panel"><div class="panel-heading"><div><h2>Rekap catatan aktual</h2><p>Biaya bahan penjualan memakai resep saat transaksi dicatat, sehingga riwayat tidak berubah saat harga resep diedit.</p></div><label class="field month-field"><span>Periode</span><input class="input" type="month" id="ops-month" value="'+opsMonth+'"></label></div><div class="ops-summary"><div><span>Pendapatan setelah biaya kanal</span><strong>'+money(revenue)+'</strong></div><div><span>Pengeluaran & pembelian tercatat</span><strong>'+money(cost)+'</strong></div><div><span>Selisih kas tercatat</span><strong>'+money(revenue-cost)+'</strong></div></div>'+helper('Selisih ini hanya mencakup transaksi yang dicatat, bukan saldo rekening atau laba akuntansi. Pembelian bahan mengurangi kas; HPP penjualan ditampilkan terpisah agar biaya stok tidak dihitung dua kali.')+'</section>'+
 '<div class="lower-grid"><section class="panel"><h2>Catat penjualan</h2><form id="sale-form" class="spaced"><label class="field"><span>Menu</span><select class="input" name="menuId" required>'+p.menus.map(m=>'<option value="'+m.id+'">'+esc(m.name)+'</option>').join('')+'</select></label><div class="field-grid">'+entryField('date','Tanggal','date',today())+entryField('qty','Jumlah cup','number',1)+'</div><label class="field"><span>Cara penjualan</span><select class="input" name="channel">'+Object.keys(channelNames).map(k=>'<option value="'+k+'">'+channelNames[k]+'</option>').join('')+'</select></label><button class="primary" '+(!p.menus.length?'disabled':'')+'>Simpan penjualan</button>'+helper('Harga, diskon, dan biaya mengikuti pengaturan saat dicatat. Stok berkurang sesuai takaran resep. Waste aktual dicatat terpisah. Ini pencatatan sederhana, belum mencakup retur atau piutang.')+'</form></section>'+
 '<section class="panel"><h2>Catat pengeluaran atau bahan</h2><form id="expense-form" class="spaced"><label class="field"><span>Jenis catatan</span><select class="input" name="type" id="entry-type"><option value="expense">Pengeluaran operasional</option><option value="purchase">Pembelian bahan</option><option value="waste">Bahan terbuang (aktual)</option></select></label>'+entryField('date','Tanggal','date',today())+entryField('note','Keterangan','text')+'<div id="material-entry" hidden><label class="field"><span>Bahan</span><select class="input" name="ingredientId">'+p.ingredients.map(i=>'<option value="'+i.id+'">'+esc(i.name)+' ('+i.unit+')</option>').join('')+'</select></label>'+entryField('qty','Jumlah dalam satuan bahan','number',1)+'</div>'+entryField('amount','Uang dibayar (Rp)','number',0)+'<button class="primary">Simpan catatan</button>'+helper('Pembelian menambah stok. Waste aktual mengurangi stok dan tidak mengurangi kas lagi. Waste transaksi ini dicatat terpisah dari asumsi waste pada simulasi.')+'</form></section></div>'+
 '<section class="panel spaced"><div class="panel-heading"><div><h2>Stok bahan saat ini</h2><p>Set awal stok dan batas minimum. Satuan mengikuti bahan pada Menu & resep.</p></div><a class="button" href="#hpp">Kelola bahan</a></div><div class="stock-grid">'+p.ingredients.map((i,n)=>'<article class="ingredient-card"><div class="panel-heading"><h2>'+esc(i.name)+'</h2><span class="chip '+(i.stock<=i.minStock?'warning':'')+'">'+(i.stock<0?'STOK NEGATIF':i.stock<=i.minStock?'PERLU DIISI':'CUKUP')+'</span></div><div class="field-grid">'+listField('ingredients',n,'stock','Stok ('+i.unit+')',{min:-1e12})+listField('ingredients',n,'minStock','Stok minimum ('+i.unit+')')+'</div></article>').join('')+(!p.ingredients.length?'<p>Tambahkan bahan pada halaman Menu & resep.</p>':'')+'</div>'+helper('Stok negatif berarti pembelian atau stok awal mungkin belum dicatat. Jika mengubah stok manual, backup tetap menyimpan nilai terakhir tetapi perubahan manual tidak menjadi transaksi kas.')+'</section>'+
 '<section class="panel spaced"><h2>Riwayat '+esc(opsMonth)+'</h2><div class="table-scroll"><table><thead><tr><th>Tanggal</th><th>Keterangan</th><th>Kas masuk</th><th>Kas keluar</th><th>HPP / waste</th><th></th></tr></thead><tbody>'+entries.slice().reverse().map(e=>'<tr><td>'+esc(e.date)+'</td><td>'+esc(e.note)+'</td><td>'+money(e.revenue)+'</td><td>'+money(e.cost)+'</td><td>'+money(e.cogs||0)+'</td><td><button class="delete-button" data-action="delete-entry" data-id="'+e.id+'" aria-label="Hapus catatan '+esc(e.note)+'">'+icon('trash')+'</button></td></tr>').join('')+'</tbody></table></div>'+(!entries.length?'<p class="empty-state">Belum ada transaksi pada periode ini.</p>':'')+'</section>';
}
function render(animate=true){
 const r=route(),p=plan();document.title=titles[r][2]+' — Ruang Kopi';
 document.querySelectorAll('nav a').forEach(a=>{const active=a.getAttribute('href')==='#'+r;a.classList.toggle('active',active);if(active)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
 document.querySelector('#breadcrumb-page').textContent=titles[r][2];
 document.querySelector('.workspace>span:nth-child(2)').innerHTML=esc(p.profile.name||'Kedai impianmu')+'<small>'+esc(p.profile.concept||'Rencana bisnis pertamaku')+'</small>';
 page.innerHTML='<div class="plan-toolbar"><label>RENCANA AKTIF <select id="active-plan" class="input" aria-label="Pilih rencana">'+store.plans.map(x=>'<option value="'+x.id+'" '+(x.id===p.id?'selected':'')+'>'+esc(x.name)+'</option>').join('')+'</select></label><span class="chip">'+(p.example?'DATA CONTOH · BISA DIEDIT':'RENCANA PRIBADI')+'</span><a href="#rencana">Kelola rencana ↗</a></div><div class="title-row"><div><div class="eyebrow">'+icon('spark')+' YOUR IDEAS, BREWING.</div><h1>'+titles[r][0]+'</h1><p>'+titles[r][1]+'</p></div><button id="export" class="button" aria-label="Unduh ringkasan CSV">'+icon('download')+'<span class="export-label">Ringkasan CSV</span></button></div>'+
 ({ringkasan:overview,profil:profilePage,modal:capitalPage,hpp:menuPage,omzet:salesPage,laba:profitPage,operasional:operationsPage,rencana:plansPage,panduan:guidePage}[r])();
 if(animate){page.classList.remove('page-enter');void page.offsetWidth;page.classList.add('page-enter');}
 save();
}
function refresh(){
 const r=route(),c=calculate(plan()),out=document.querySelector('#result');
 if(out)out.innerHTML=({modal:capitalResult,hpp:menuResult,omzet:salesResult,laba:profitResult}[r])();
 for(const id of ['advice-list','sales-advice','profit-advice']){const el=document.getElementById(id);if(el)el.innerHTML=adviceCards();}
 const scenarios=document.querySelector('#scenario-table');if(scenarios)scenarios.innerHTML=scenarioTable();
 const revenue=document.querySelector('#sim-revenue');if(revenue)revenue.textContent=money(c.revenue);
 const cups=document.querySelector('#cup-output');if(cups)cups.textContent=integer(plan().assumptions.cups);
 document.querySelectorAll('[data-path="assumptions.cups"]').forEach(el=>{if(el!==document.activeElement)el.value=plan().assumptions.cups;if(el.type==='range'){el.max=Math.max(200,plan().assumptions.cups);el.style.setProperty('--range',(plan().assumptions.cups/el.max*100)+'%');el.nextElementSibling.lastElementChild.textContent=integer(el.max)+' cup/hari';}});
 if(r==='operasional')document.querySelectorAll('.stock-grid .ingredient-card').forEach((card,i)=>{
  const material=plan().ingredients[i],chip=card.querySelector('.chip');
  chip.classList.toggle('warning',material.stock<=material.minStock);chip.textContent=material.stock<0?'STOK NEGATIF':material.stock<=material.minStock?'PERLU DIISI':'CUKUP';
 });
 if(r==='ringkasan'){const stats=document.querySelectorAll('.stat strong');[c.capital,c.variable,c.revenue,c.profit].forEach((v,i)=>stats[i].textContent=money(v));}
}
function error(el,message){
 el.setAttribute('aria-invalid',message?'true':'false');
 const target=el.getAttribute('aria-describedby');if(target){const holder=document.getElementById(target);if(holder)holder.textContent=message;}
}
page.addEventListener('input',e=>{
 const el=e.target;if(!el.dataset.path||el.tagName==='SELECT')return;
 let value=el.value;
 if(el.type==='number'||el.type==='range'){
  value=Number(value);
  const min=Number(el.getAttribute('min')??0),max=Number(el.getAttribute('max')||1e12),step=el.getAttribute('step');
  if(el.value===''||!Number.isFinite(value)||value<min||value>max||(step==='1'&&!Number.isInteger(value))){error(el,el.value===''?'Isi angka agar hasil diperbarui.':'Gunakan angka '+min+'–'+max+(step==='1'?' (bilangan bulat).':'.'));return;}
 }
 if(el.type==='date'&&value&&!/^\d{4}-\d{2}-\d{2}$/.test(value)){error(el,'Isi tanggal yang valid.');return;}
 error(el,'');setPath(plan(),el.dataset.path,value);save();refresh();
 if(el.dataset.path==='name'){document.querySelector('#active-plan option:checked').textContent=plan().name;}
 if(el.dataset.path.startsWith('profile.'))document.querySelector('.workspace>span:nth-child(2)').innerHTML=esc(plan().profile.name||'Kedai impianmu')+'<small>'+esc(plan().profile.concept||'Rencana bisnis pertamaku')+'</small>';
});
page.addEventListener('change',e=>{
 const el=e.target;
 if(el.id==='active-plan'){store.activeId=el.value;selectedMenu='';firstVisit=false;render();return;}
 if(el.id==='ops-month'){if(/^\d{4}-\d{2}$/.test(el.value)){opsMonth=el.value;render(false);}return;}
 if(el.id==='entry-type'){
  const material=el.value!=='expense';document.querySelector('#material-entry').hidden=!material;
  const amount=page.querySelector('[name="amount"]');amount.disabled=el.value==='waste';if(amount.disabled)amount.value=0;
  page.querySelector('#material-entry [name="qty"]').required=material;return;
 }
 if(el.id==='import-file'){importBackup(el.files?.[0]).finally(()=>{el.value='';});return;}
 if(el.tagName==='SELECT'&&el.dataset.path){setPath(plan(),el.dataset.path,el.value);save();render(false);}

});
function download(content,type,name){
 const blob=new Blob([content],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function exportCSV(){
 const p=plan(),c=calculate(p);
 const quote=value=>'"'+String(typeof value==='string'&&/^[=+@\-\t\r]/.test(value)?"'"+value:value).replace(/"/g,'""')+'"';
 const rows=[['RUANG KOPI — SIMULASI',p.name],['Nama kedai',p.profile.name],['Modal pembukaan',c.setup],['Target cadangan',p.reserve],['Total dana dibutuhkan',c.capital],['Dana tersedia',p.funds],['Kekurangan',c.shortfall],['Biaya variabel rata-rata/cup',c.variable],['Omzet setelah diskon/bulan',c.revenue],['Laba sebelum pajak/bulan',c.profit],['BEP cup/bulan',c.bep??'Tidak tercapai'],[],['Menu','HPP bahan termasuk waste','Harga di tempat','Harga takeaway','Harga delivery','Bobot penjualan'],...p.menus.map(m=>[m.name,recipeCost(p,m)/(1-p.assumptions.waste/100),m.prices.dinein,m.prices.takeaway,m.prices.delivery,m.mix]),[],['CATATAN AKTUAL','Tanggal','Keterangan','Kas masuk','Kas keluar','HPP/waste'],...p.ledger.map(e=>[e.type,e.date,e.note,e.revenue,e.cost,e.cogs||0])];
 download('\uFEFF'+rows.map(x=>x.map(quote).join(',')).join('\r\n'),'text/csv;charset=utf-8','ringkasan-ruang-kopi.csv');notify('Ringkasan CSV diunduh.');
}
function addPlan(sample,replace=false){
 if(!replace&&store.plans.length>=20){notify('Maksimal 20 rencana. Backup lalu hapus yang tidak diperlukan.');return;}
 const p=createPlan(sample);
 if(replace)store.plans=store.plans.filter(x=>x.id!==store.activeId);
 store.plans.push(p);store.activeId=p.id;selectedMenu='';firstVisit=false;render();notify(sample?'Contoh kedai siap dipelajari. Semua angka bisa diedit.':'Rencana kosong siap kamu isi.');
}
async function importBackup(file){
 if(!file)return;
 if(file.size>2*1024*1024){notify('File terlalu besar. Maksimal 2 MB.');return;}
 try{
  const backup=JSON.parse(await file.text());
  if(backup.version!==3||!Array.isArray(backup.plans)||backup.plans.length===0||backup.plans.length>20||!backup.plans.every(validatePlan))throw Error('Format backup tidak valid.');
  if(backup.plans.length+store.plans.length>20){notify('Jumlah rencana setelah impor melebihi 20. Tidak ada data yang diubah.');return;}
  const incoming=structuredClone(backup.plans).map(p=>({...p,id:uid(),name:(p.name+' (dipulihkan)').slice(0,100)}));
  store.plans.push(...incoming);store.activeId=incoming[0].id;firstVisit=false;selectedMenu='';save();render();notify(incoming.length+' rencana dipulihkan sebagai salinan.');
 }catch(_){notify('Backup tidak valid atau rusak. Data yang ada tetap aman.');}
}
page.addEventListener('click',e=>{
 const b=e.target.closest('button');if(!b)return;
 const p=plan(),action=b.dataset.action,i=Number(b.dataset.index);
 if(b.id==='export'){exportCSV();return;}
 switch(action){
  case 'start-sample':addPlan(true,true);break;
  case 'start-blank':firstVisit=false;save();render();notify('Mulai isi profil atau kebutuhan modalmu.');break;
  case 'new-blank':addPlan(false);break;
  case 'new-sample':addPlan(true);break;
  case 'open-plan':store.activeId=b.dataset.id;selectedMenu='';firstVisit=false;render();break;
  case 'duplicate-plan':{
   if(store.plans.length>=20){notify('Maksimal 20 rencana.');break;}
   const copy=structuredClone(store.plans.find(x=>x.id===b.dataset.id));copy.id=uid();copy.name=(copy.name+' (salinan)').slice(0,100);store.plans.push(copy);store.activeId=copy.id;selectedMenu='';render();notify('Rencana beserta catatannya disalin.');break;
  }
  case 'delete-plan':{
   if(store.plans.length<=1)break;
   const index=store.plans.findIndex(x=>x.id===b.dataset.id),removed=store.plans.splice(index,1)[0];
   if(store.activeId===removed.id)store.activeId=store.plans[0].id;
   selectedMenu='';render();notify('Rencana dihapus.',()=>{if(store.plans.length>=20)return;store.plans.splice(index,0,removed);store.activeId=removed.id;render();});break;
  }
  case 'backup':download(JSON.stringify({version:3,exportedAt:new Date().toISOString(),plans:store.plans},null,2),'application/json','backup-ruang-kopi-'+today()+'.json');notify('Backup seluruh rencana diunduh.');break;
  case 'add-capital':if(p.capital.length>=200){notify('Maksimal 200 komponen.');break;}p.capital.push({id:uid(),name:'Kebutuhan baru',cost:0});render(false);break;
  case 'remove-capital':{const removed=p.capital.splice(i,1)[0];render(false);notify('Kebutuhan dihapus.',()=>{p.capital.splice(i,0,removed);render(false);});break;}
  case 'add-menu':{
   if(p.menus.length>=100){notify('Maksimal 100 menu.');break;}
   const m={id:uid(),name:'Menu baru',mix:1,prices:{dinein:0,takeaway:0,delivery:0},recipe:[]};p.menus.push(m);selectedMenu=m.id;render(false);notify('Menu baru ditambahkan. Isi harga dan resepnya.');break;
  }
  case 'select-menu':selectedMenu=b.dataset.id;render(false);break;
  case 'remove-menu':{
   const index=p.menus.findIndex(m=>m.id===selectedMenu),removed=p.menus.splice(index,1)[0];selectedMenu='';render(false);notify('Menu dihapus. Riwayat transaksi tetap tersimpan.',()=>{p.menus.splice(index,0,removed);selectedMenu=removed.id;render(false);});break;
  }
  case 'add-recipe':{
   const m=p.menus.find(x=>x.id===selectedMenu);
   if(!p.ingredients.length){notify('Tambahkan bahan di bagian Harga beli bahan dahulu.');page.querySelector('[data-action="add-ingredient"]')?.focus();break;}
   if(m.recipe.length>=100){notify('Maksimal 100 baris bahan per resep.');break;}
   m.recipe.push({ingredientId:p.ingredients[0].id,qty:0});render(false);break;
  }
  case 'remove-recipe':{
   const m=p.menus.find(x=>x.id===selectedMenu),removed=m.recipe.splice(i,1)[0];render(false);notify('Bahan dikeluarkan dari resep.',()=>{m.recipe.splice(i,0,removed);render(false);});break;
  }
  case 'add-ingredient':{
   if(p.ingredients.length>=200){notify('Maksimal 200 bahan.');break;}
   p.ingredients.push({id:uid(),name:'Bahan baru',packPrice:0,packQty:1000,unit:'g',stock:0,minStock:0});render(false);
   const cards=page.querySelectorAll('.ingredient-card');cards[cards.length-1]?.scrollIntoView({behavior:reducedMotion()?'auto':'smooth',block:'center'});notify('Bahan ditambahkan. Pilih satuan sebelum memakainya di resep.');break;
  }
  case 'remove-ingredient':{
   const item=p.ingredients[i];
   if(p.menus.some(m=>m.recipe.some(r=>r.ingredientId===item.id))||p.ledger.some(e=>e.movements.some(m=>m.id===item.id))){notify('Bahan masih dipakai dalam resep atau riwayat stok. Lepaskan dari resep terlebih dahulu; bahan bersejarah perlu dipertahankan.');break;}
   p.ingredients.splice(i,1);render(false);notify('Bahan dihapus.',()=>{p.ingredients.splice(i,0,item);render(false);});break;
  }
  case 'delete-entry':{
   const index=p.ledger.findIndex(e=>e.id===b.dataset.id),entry=p.ledger.splice(index,1)[0];
   entry.movements.forEach(m=>{p.ingredients.find(i=>i.id===m.id).stock-=m.qty;});
   render(false);notify('Catatan dihapus dan perubahan stok dibalik.',()=>{p.ledger.splice(index,0,entry);entry.movements.forEach(m=>{p.ingredients.find(i=>i.id===m.id).stock+=m.qty;});render(false);});break;
  }
 }
});
page.addEventListener('submit',event=>{
 event.preventDefault();const form=event.target,p=plan();
 if(!['sale-form','expense-form'].includes(form.id))return;
 if(!form.reportValidity())return;
 if(p.ledger.length>=5000){notify('Maksimal 5.000 catatan per rencana. Backup lalu buat rencana baru.');return;}
 const value=name=>form.elements.namedItem(name)?.value;
 const date=value('date');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||Number.isNaN(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date){notify('Tanggal tidak valid.');return;}
 let entry={id:uid(),date,type:'expense',note:'',revenue:0,cost:0,cogs:0,movements:[]};
 if(form.id==='sale-form'){
  const m=p.menus.find(m=>m.id===value('menuId')),qty=Number(value('qty')),channel=value('channel');
  if(!m||!Number.isInteger(qty)||qty<=0||qty>1e6||!Object.hasOwn(channelNames,channel)){notify('Pilih menu dan jumlah cup yang valid.');return;}
  const v=menuChannel(p,m,channel);
  entry={...entry,type:'sale',note:m.name+' · '+qty+' cup · '+channelNames[channel],revenue:(v.net-v.fees)*qty,cogs:(v.base+p.channels[channel].packaging)*qty};
  // Aktual memakai takaran resep, bukan tambahan waste simulasi. Waste aktual dicatat tersendiri.
  const changes=new Map();
  m.recipe.forEach(r=>changes.set(r.ingredientId,(changes.get(r.ingredientId)||0)-r.qty*qty));
  entry.movements=[...changes].map(([id,qty])=>({id,qty}));
  if(entry.revenue<0){notify('Total komisi dan biaya pembayaran melebihi pendapatan. Perbaiki pengaturan biaya.');return;}
 }else{
  const type=value('type'),amount=Number(value('amount')),note=value('note').trim();
  if(!note||note.length>300||!Number.isFinite(amount)||amount<0||amount>1e12){notify('Isi keterangan dan uang dibayar yang valid.');return;}
  entry={...entry,type,note,cost:type==='waste'?0:amount};
  if(type==='purchase'||type==='waste'){
   const material=p.ingredients.find(i=>i.id===value('ingredientId')),qty=Number(value('qty'));
   if(!material||!Number.isFinite(qty)||qty<=0||qty>1e12){notify('Pilih bahan dan jumlah lebih dari nol.');return;}
   entry.movements=[{id:material.id,qty:type==='purchase'?qty:-qty}];
   entry.note=(note+' · '+material.name).slice(0,300);
   if(type==='waste')entry.cogs=material.packPrice/material.packQty*qty;
  }
 }
 if(!Number.isFinite(entry.revenue)||entry.revenue>1e12||!Number.isFinite(entry.cogs)||entry.cogs>1e12||entry.movements.some(m=>Math.abs(p.ingredients.find(i=>i.id===m.id).stock+m.qty)>1e12)){notify('Nilai transaksi terlalu besar. Periksa harga dan jumlah.');return;}
 entry.movements.forEach(m=>{p.ingredients.find(i=>i.id===m.id).stock+=m.qty;});
 p.ledger.push(entry);opsMonth=date.slice(0,7);save();render(false);
 notify(p.ingredients.some(i=>i.stock<0)?'Catatan tersimpan. Ada stok negatif; periksa stok awal dan pembelian.':'Catatan aktual tersimpan.');
});
document.querySelector('#toast').addEventListener('click',e=>{if(e.target.closest('#undo')&&undoAction){undoAction();notify('Perubahan diurungkan.');}});
document.addEventListener('pointerdown',e=>{
 const target=e.target.closest('button,.button');if(!target||reducedMotion()||target.disabled)return;
 const rect=target.getBoundingClientRect(),size=Math.max(rect.width,rect.height),ripple=document.createElement('span');
 ripple.className='ripple';ripple.style.cssText='width:'+size+'px;height:'+size+'px;left:'+(e.clientX-rect.left-size/2)+'px;top:'+(e.clientY-rect.top-size/2)+'px';target.append(ripple);setTimeout(()=>ripple.remove(),650);
});
document.querySelector('.skip-link').addEventListener('click',e=>{e.preventDefault();page.focus({preventScroll:true});page.scrollIntoView({behavior:reducedMotion()?'auto':'smooth'});});
window.addEventListener('hashchange',()=>{render();page.focus({preventScroll:true});window.scrollTo({top:0,behavior:reducedMotion()?'auto':'smooth'});});
render();
